/*************************
*Joseph Barton           *
*CPSC 1021-004, F16      *
*Lab 11                  *
*jbarto3                 *
**************************/

#ifndef __FUNCTIONS_H__
#define __FUNCTIONS_H__

void print_array( int array[], int array_size );
void selection_sort( int array[], int array_size );
int  linear_search( int array[], int array_size, int search_item );

#endif
